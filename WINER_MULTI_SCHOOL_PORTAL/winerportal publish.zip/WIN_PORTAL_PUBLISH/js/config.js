﻿var config = {
    apiUrl: "http://localhost:3077/",
    schoolApi: "api/schools/"
}