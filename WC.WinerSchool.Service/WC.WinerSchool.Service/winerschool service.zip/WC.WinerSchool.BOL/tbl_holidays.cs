﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WC.WinerSchool.BOL
{
    public class tbl_holidays
    {
        public int Id;
        public String Date;
        public String Type;
        public int ClassID;
        public String Desc;
        public int GroupID;
        public long SyncDate;
    }
}
