﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WC.WinerSchool.BOL
{
    public class PeriodDetails
    {
        public int Id;
        public string PeriodName;
        public string FrequencyId;
        public int Order;
        public long SyncDate;
    }
}
