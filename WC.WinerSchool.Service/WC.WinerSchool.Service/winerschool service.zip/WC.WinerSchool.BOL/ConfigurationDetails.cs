﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WC.WinerSchool.BOL
{
    public class ConfigurationDetails
    {
        public int Id;
        public string Module;
        public String ConfigName;
        public String Value;
        public String SubValue;
        public String Discription;
        public long SyncDate;
    }
}
