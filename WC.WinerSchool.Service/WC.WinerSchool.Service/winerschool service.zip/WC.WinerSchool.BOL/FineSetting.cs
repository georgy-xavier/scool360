﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WC.WinerSchool.BOL
{
    public class FineSetting
    {
        public int Id;
        public double Amount;
        public double Frequency;
        public string Type;
        public int FeeId;
        public int Finedate;
        public int FineAmounttype;
        public int FineDuration;
        public long SyncDate;
    }
}
