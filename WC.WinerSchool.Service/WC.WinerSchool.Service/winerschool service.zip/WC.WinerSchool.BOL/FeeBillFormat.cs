﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WC.WinerSchool.BOL
{
    public class FeeBillFormat
    {
        public int Id;
        public string Name;
        public int NeedOfficeCopy;
        public string PageName;
        public int IsPDF;
        public long SyncDate;
    }
}
