﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WC.WinerSchool.BOL
{
    public class FeeAdvanceDetails
    {
        public int Id;
        public int StudentId;
        public string StudentName;
        public string FeeName;
        public string PeriodName;
        public double Amount;
        public int BatchId;
        public int FeeId;
        public int PeriodId;
        public string TempId;
        public long SyncDate;
    }
}
