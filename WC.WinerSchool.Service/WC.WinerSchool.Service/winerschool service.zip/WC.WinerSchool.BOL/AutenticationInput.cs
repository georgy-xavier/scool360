﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WC.WinerSchool.BOL
{
    public class AutenticationInput
    {
        public String UserName;
        public String Password;
    }

}
