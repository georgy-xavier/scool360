﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WC.WinerSchool.BOL
{
    public class OtherFeeDetails
    {
        public int Id;
        public string Name;
        public string Description;
        public int Refundable;
        public long SyncDate;
    }
}
