﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WC.WinerSchool.BOL
{
    public class tbl_holidayconfig
    {
        public int Id;
        public String day;
        public int StudentStatus;
        public String StaffStatus;
        public long SyncDate;
    }
}
