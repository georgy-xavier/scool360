﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WC.WinerSchool.BOL
{
    public class ClassDetails
    {
        public int ClassId;
        public String ClassName;
        public int StandardId;
        public String Standard;
        public String Division;
        public int TotalSeats;
        public int PeriodCount;
        public String ClassTeacher;
        public long SyncDate;
    }
}
